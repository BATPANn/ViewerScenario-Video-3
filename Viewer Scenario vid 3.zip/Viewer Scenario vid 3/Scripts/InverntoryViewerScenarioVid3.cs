using UnityEngine;

public class InverntoryViewerScenarioVid3 : MonoBehaviour
{


    public bool HaveFuelCanister = false;


    
}
